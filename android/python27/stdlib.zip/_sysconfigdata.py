# system configuration generated and used by the sysconfig module
build_time_vars = {}
